<template>
  <div>
    <h1>Könyvek oldal</h1>
    <p>Itt vannak a könyvek adatai.</p>
  </div>
</template>

<script>
export default {
  name: 'Books',
}
</script>
